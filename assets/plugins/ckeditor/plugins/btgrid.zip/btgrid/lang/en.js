"use strict"

CKEDITOR.plugins.setLang( 'btgrid', 'en', {
	selNumCols: 'Select number of columns',
  genNrRows: 'Add number of rows to generate',
	infoTab: 'Info',
	createBtGrid: 'Create a Bootstrap grid',
	editBtGrid: 'Edit Bootstrap grid',
	numColsError:  'Please select number of columns.',
	numRowsError: 'Please insert numeric value for Number of rows.',
} );
